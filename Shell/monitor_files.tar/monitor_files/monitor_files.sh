#! /bin/bash
########################################################
# Filename: ./monitor_files.sh
# Date: 2015-02-02
# Author: chenhuidong
# Email: chdyczx@live.com
# Note: 
########################################################

usage()
{
	echo "usage:"
	echo "	./monitor_files.sh"
	echo "	monitor folders in filelst.conf of users in userlst.conf"
	echo ""
}

remote_cmd()
{
	ssh $1 "$2"
}


monitor_folders()
{
	filename=./usrlist.conf
	filename2=./filelist.conf
	
	if [ ! -f $filename -o ! -f $filename2 ]
	then
		echo "File $filename or $filename2 is not exist."
		echo ""
		usage
		exit 1
	fi
	
	cat $filename | while read line
	do
		v_ip=`echo $line | awk -F " " '{print $1}'`
		echo $v_ip
		cat $filename2 | while read line2
		do
			v_cmdline=`echo $line2 |awk -F "%" '{print $1}'`
			v_maxvalue=`echo $line2 |awk -F "%" '{print $2}'`
			v_style=`echo $line2 |awk -F "%" '{print $3}'`
			echo $v_cmdline, $v_maxvalue, $v_style
			
			v_num=`remote_cmd $v_ip "$v_cmdline"`
			echo $v_num 
			
			if [ $v_num -gt $v_maxvalue ]
			then
				v_content=`eval echo $v_style`;
                        	echo $v_content
				sqlplus "jd/u_6Ye_6F@ocsact" <<!
               			exec pm.p_send_sms(13260941409,'$v_content');
				exec pm.p_send_sms(18606191852,'$v_content');
                                exec pm.p_send_sms(13218028296,'$v_content');
                                exec pm.p_send_sms(15651601805,'$v_content');
                                exec pm.p_send_sms(15651600501,'$v_content');
               			exit
!
			fi
			echo ""
		done
	done
}

main()
{
	monitor_folders
}

main
exit 0
