#!/bin/bash

cp /home/chenhuidong/MyProgram/MyGithub/MyGit/MyScript/MyWeb/*.cgi /var/www/html/cgi-bin
