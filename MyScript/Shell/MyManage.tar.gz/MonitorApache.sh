#! /bin/bash

v_count=`ps -ef | grep apache | grep -v grep | wc -l`

if [[ v_count -eq 0 ]]
then
    apache2ctl start
fi
